# Write a security audit report for UPI applications and mobile wallets, including recommendations for secure net banking.

print("SECURITY AUDIT REPORT")

applications = {
    "UPI Application": [
        "Enable UPI PIN protection.",
        "Enable biometric or application lock.",
        "Verify receiver details before payment.",
        "Enable transaction alerts.",
        "Review transaction history."
    ],
    "Mobile Wallet": [
        "Enable PIN or biometric authentication.",
        "Enable OTP verification where supported.",
        "Remove unused linked cards.",
        "Check wallet balance regularly.",
        "Update the application."
    ],
    "Net Banking": [
        "Use the official bank website.",
        "Use a strong unique password.",
        "Enable two-factor authentication.",
        "Avoid public Wi-Fi.",
        "Logout after transactions.",
        "Monitor account statements."
    ]
}

for app, controls in applications.items():
    print("\n", app)
    for control in controls:
        print("-", control)

print("\nAUDIT RECOMMENDATIONS")

print("1. Update banking applications regularly.")
print("2. Never share PIN, OTP or password.")
print("3. Report suspicious transactions immediately.")
print("4. Use only trusted applications and websites.")

print("\nRESULT: Banking security audit completed.")
