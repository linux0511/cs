# Design the procedure for enabling two-factor authentication and installing security patch updates on computers and mobile phones.

print("TWO-FACTOR AUTHENTICATION")

steps = [
    "Open account settings and select Security.",
    "Choose Two-Factor Authentication.",
    "Select OTP or authenticator application.",
    "Scan QR code if using an authenticator application.",
    "Enter the verification code.",
    "Save backup recovery codes securely.",
    "Test login to verify 2FA."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\nSECURITY PATCH INSTALLATION")

updates = [
    "Open computer or mobile Settings.",
    "Select Windows Update or Software Update.",
    "Check available security updates.",
    "Download patches from official sources.",
    "Install the updates.",
    "Restart the device if required.",
    "Check update history or software version.",
    "Enable automatic updates."
]

for i, step in enumerate(updates, 1):
    print(i, ".", step)

print("\nRESULT: 2FA and software update procedures completed.")
