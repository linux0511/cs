# Write a cybercrime incident response checklist covering evidence collection, complaint registration, and mobile security configuration.

print("CYBERCRIME INCIDENT RESPONSE")

print("\n1. EVIDENCE COLLECTION")

evidence = [
    "Take screenshots of fraudulent messages and websites.",
    "Save transaction ID and payment reference number.",
    "Record the date, time and amount of the fraud.",
    "Save suspect phone number, email ID or UPI ID.",
    "Download the bank statement showing the transaction.",
    "Preserve emails, SMS messages and call records."
]

for i, item in enumerate(evidence, 1):
    print(i, ".", item)

print("\n2. COMPLAINT REGISTRATION")

steps = [
    "Contact the bank immediately to report the fraud.",
    "Call 1930 for financial cyber fraud.",
    "Open the official cybercrime.gov.in portal.",
    "Select File a Complaint and register using OTP.",
    "Enter victim details and explain the incident.",
    "Upload transaction proof and supporting evidence.",
    "Submit the complaint and save acknowledgement number."
]

for i, item in enumerate(steps, 1):
    print(i, ".", item)

print("\n3. MOBILE SECURITY CONFIGURATION")

security = [
    "Set a strong screen lock or password.",
    "Enable fingerprint or face authentication.",
    "Enable two-factor authentication on important accounts.",
    "Install operating system security updates.",
    "Remove unknown and unused applications.",
    "Restrict unnecessary camera, microphone and location access.",
    "Enable device tracking and remote lock features."
]

for item in security:
    print("-", item)

print("\n4. SECURITY VERIFICATION REPORT")

print("Screen Lock: Enabled")
print("Two-Factor Authentication: Enabled")
print("Software Updates: Check latest version")
print("App Permissions: Unnecessary access restricted")

print("\nRESULT: Evidence is preserved and mobile security is improved.")
