# Write a step-by-step guide for reporting cybercrime through the online portal and at a Cyber Crime Police Station.

print("CYBERCRIME COMPLAINT PROCEDURE")

print("\n1. ONLINE CYBERCRIME PORTAL")

portal = [
    "Open the official website cybercrime.gov.in.",
    "Select File a Complaint.",
    "Accept the terms and conditions.",
    "Register using a mobile number and OTP.",
    "Select the appropriate cybercrime category.",
    "Enter victim information and incident details.",
    "Provide transaction ID, date, amount and suspect details.",
    "Upload screenshots, bank statements and other evidence.",
    "Submit the complaint and save acknowledgement number."
]

for i, step in enumerate(portal, 1):
    print(i, ".", step)

print("\n2. CYBER CRIME POLICE STATION")

police = [
    "Visit the nearest Cyber Crime Police Station.",
    "Carry identity proof and supporting documents.",
    "Prepare a written complaint describing the incident.",
    "Mention the date, time, amount and method of fraud.",
    "Attach transaction records and screenshots.",
    "Submit the complaint to the police officer.",
    "Request registration of FIR or complaint, as applicable.",
    "Collect acknowledgement and follow up on the case."
]

for i, step in enumerate(police, 1):
    print(i, ".", step)

print("\n3. IMPORTANT CONTACT")

print("Cyber Financial Fraud Helpline: 1930")
print("Online Portal: https://cybercrime.gov.in")

print("\nRESULT: Online and offline cybercrime reporting procedures prepared.")
