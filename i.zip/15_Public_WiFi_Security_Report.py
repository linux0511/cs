# Design suitable Wi-Fi security settings for computers and mobile phones and explain the risks of using public Wi-Fi networks.

print("PUBLIC WI-FI SECURITY REPORT")

print("\n1. POSSIBLE SECURITY RISKS")

risks = [
    "Packet sniffing can capture unprotected network traffic.",
    "Fake hotspots can collect login credentials.",
    "MITM attacks can intercept communication.",
    "Malware attacks can affect connected devices.",
    "Unsecured networks may expose personal information."
]

for item in risks:
    print("-", item)

print("\n2. COMPUTER SECURITY SETTINGS")

computer = [
    "Enable firewall protection.",
    "Disable file sharing on public networks.",
    "Turn off automatic Wi-Fi connection.",
    "Keep antivirus and OS updated.",
    "Avoid sensitive online transactions."
]

for item in computer:
    print("-", item)

print("\n3. MOBILE SECURITY SETTINGS")

mobile = [
    "Disable automatic connection to unknown networks.",
    "Forget public networks after use.",
    "Use trusted VPN protection when appropriate.",
    "Avoid entering banking passwords on unknown networks.",
    "Keep mobile software updated."
]

for item in mobile:
    print("-", item)

print("\nRESULT: These configurations reduce public Wi-Fi security risks.")
