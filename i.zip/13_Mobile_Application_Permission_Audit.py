# Design mobile application permission settings by reviewing installed applications, restricting unnecessary access, and explaining security benefits.

print("MOBILE APPLICATION PERMISSION AUDIT")

print("\n1. PERMISSION REVIEW")

permissions = {
    "Camera": "Allow only for photography and video applications.",
    "Microphone": "Allow only for calling and recording applications.",
    "Contacts": "Allow only for communication applications.",
    "Location": "Allow only for navigation applications.",
    "SMS": "Restrict unnecessary access to protect OTP messages."
}

for permission, reason in permissions.items():
    print(permission, ":", reason)

print("\n2. PERMISSION MANAGEMENT PROCEDURE")

steps = [
    "Open Settings on the mobile phone.",
    "Select Apps or Permission Manager.",
    "Choose an installed application.",
    "Open its permission settings.",
    "Review requested sensitive information.",
    "Deny unnecessary permissions.",
    "Allow access only while using the application when appropriate."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n3. SECURITY BENEFITS")

print("- Prevents unnecessary personal data collection.")
print("- Reduces misuse of camera and microphone.")
print("- Protects contacts and location information.")
print("- Reduces privacy and security risks.")

print("\nRESULT: Unnecessary application permissions are restricted.")
