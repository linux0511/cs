# Design a secure public Wi-Fi setup for computers and mobile phones, and explain cybercrime evidence documentation and reporting procedures.

print("PUBLIC WI-FI SECURITY SETUP")

print("\n1. SECURITY THREATS")

threats = [
    "Packet sniffing can capture unprotected network traffic.",
    "Fake hotspots can steal user credentials.",
    "MITM attacks can intercept communication.",
    "Malware may enter through malicious downloads.",
    "Weak network security can expose personal information."
]

for item in threats:
    print("-", item)

print("\n2. COMPUTER SECURITY CONFIGURATION")

computer = [
    "Enable Windows Firewall to filter network traffic.",
    "Disable file and printer sharing on public networks.",
    "Disable automatic connection to unknown Wi-Fi.",
    "Keep antivirus and operating system updated.",
    "Avoid accessing banking websites on public networks."
]

for item in computer:
    print("-", item)

print("\n3. MOBILE SECURITY CONFIGURATION")

mobile = [
    "Disable automatic connection to public Wi-Fi.",
    "Forget unknown wireless networks.",
    "Use trusted VPN protection when appropriate.",
    "Avoid entering passwords on suspicious websites.",
    "Keep mobile operating system updated."
]

for item in mobile:
    print("-", item)

print("\n4. SECURE NETWORK SCHEMATIC")

print("Computer / Mobile")
print("       |")
print(" Firewall / Device Security")
print("       |")
print(" Trusted Wi-Fi / VPN")
print("       |")
print(" Secure Internet Connection")
print("       |")
print(" Official Website")

print("\n5. CYBERCRIME EVIDENCE DOCUMENTATION")

evidence = [
    "Transaction ID identifies the fraudulent payment.",
    "Bank statement provides financial transaction proof.",
    "Screenshots preserve fraudulent messages and websites.",
    "Phone number or UPI ID helps identify the suspect.",
    "Date and time establish the incident timeline.",
    "Email and SMS records provide communication evidence."
]

for item in evidence:
    print("-", item)

print("\n6. REPORTING PROCEDURE")

print("1. Inform the bank immediately.")
print("2. Call cybercrime helpline 1930.")
print("3. Register complaint at cybercrime.gov.in.")
print("4. Upload preserved evidence.")
print("5. Save acknowledgement number.")

print("\nRESULT: Secure network configuration and evidence report prepared.")
