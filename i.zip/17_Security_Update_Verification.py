# Design a procedure to check, download, and install security updates on a computer and mobile phone, and prepare an update status verification report.

print("SECURITY UPDATE VERIFICATION")

print("\n1. COMPUTER UPDATE PROCEDURE")

computer = [
    "Open Windows Settings.",
    "Select Windows Update.",
    "Click Check for Updates.",
    "Download available security patches.",
    "Install updates and restart the computer.",
    "Open Update History to verify installation."
]

for i, step in enumerate(computer, 1):
    print(i, ".", step)

print("\n2. MOBILE UPDATE PROCEDURE")

mobile = [
    "Open mobile Settings.",
    "Select Software Update.",
    "Check for available updates.",
    "Download updates from the official source.",
    "Install the update and restart the device.",
    "Verify the installed software version."
]

for i, step in enumerate(mobile, 1):
    print(i, ".", step)

print("\n3. UPDATE STATUS REPORT")

print("Computer:")
print("- Installed updates: Verify through Update History.")
print("- Pending updates: Check Windows Update.")

print("\nMobile:")
print("- Installed version: Check Software Information.")
print("- Pending updates: Check Software Update.")

print("\nRESULT: Update status can be verified on both devices.")
