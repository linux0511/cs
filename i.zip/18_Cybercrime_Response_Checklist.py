# Write a cybercrime response checklist for phishing or online financial fraud, covering immediate actions, evidence collection, and complaint registration.

print("CYBERCRIME RESPONSE CHECKLIST")

print("\n1. IMMEDIATE ACTIONS")

actions = [
    "Identify the suspicious transaction or phishing activity.",
    "Contact the bank to secure the affected account.",
    "Call 1930 immediately for financial cyber fraud.",
    "Change compromised passwords.",
    "Block affected cards or UPI access if required."
]

for item in actions:
    print("-", item)

print("\n2. EVIDENCE COLLECTION")

evidence = [
    "Save screenshots of phishing messages.",
    "Record transaction ID and fraud amount.",
    "Note date and time of the incident.",
    "Save suspect phone number or email address.",
    "Download bank statement.",
    "Preserve suspicious website links and emails."
]

for item in evidence:
    print("-", item)

print("\n3. COMPLAINT REGISTRATION")

steps = [
    "Visit cybercrime.gov.in.",
    "Select File a Complaint.",
    "Register using mobile number and OTP.",
    "Enter complete incident information.",
    "Upload collected evidence.",
    "Submit and save acknowledgement number."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\nRESULT: Evidence collection and complaint procedure prepared.")
