# Design a security checklist for UPI payments, mobile wallets and net banking, and write a user-awareness guide.

print("ONLINE BANKING SECURITY CHECKLIST")

security = {
    "UPI": [
        "Use a strong UPI PIN.",
        "Verify receiver name before payment.",
        "Never share OTP or UPI PIN.",
        "Avoid unknown QR codes.",
        "Enable transaction alerts."
    ],
    "Mobile Wallet": [
        "Enable application lock.",
        "Use OTP verification where available.",
        "Review wallet transactions.",
        "Remove unused linked cards.",
        "Install updates regularly."
    ],
    "Net Banking": [
        "Use the official bank website.",
        "Create a strong unique password.",
        "Enable two-factor authentication.",
        "Avoid public computers and Wi-Fi.",
        "Logout after completing transactions."
    ]
}

for name, controls in security.items():
    print("\n", name)
    for item in controls:
        print("[ ]", item)

print("\nUSER AWARENESS GUIDELINES")

awareness = [
    "Never share OTP, PIN, CVV or passwords.",
    "Do not click suspicious links.",
    "Verify payment requests before approving.",
    "Never install unknown screen-sharing applications.",
    "Check bank statements regularly.",
    "Report fraudulent transactions immediately."
]

for i, item in enumerate(awareness, 1):
    print(i, ".", item)

print("\nRESULT: Online banking awareness checklist prepared.")
