# Design an incident-reporting procedure for a compromised bank account and list the information required to file a cybercrime complaint.

print("BANK ACCOUNT COMPROMISE REPORT")

print("\n1. IMMEDIATE RESPONSE")

actions = [
    "Contact the bank and report unauthorised transactions.",
    "Block affected cards or UPI access if required.",
    "Change banking password and UPI PIN.",
    "Call cybercrime helpline 1930 for financial fraud.",
    "Preserve transaction messages and bank statements."
]

for i, action in enumerate(actions, 1):
    print(i, ".", action)

print("\n2. INFORMATION REQUIRED FOR COMPLAINT")

details = [
    "Victim name and registered mobile number.",
    "Bank name and relevant account details.",
    "Transaction ID and payment reference number.",
    "Fraud amount and transaction date.",
    "Suspect phone number, UPI ID or email address.",
    "Screenshots of fraudulent messages.",
    "Bank statement showing suspicious transactions."
]

for item in details:
    print("-", item)

print("\n3. COMPLAINT REGISTRATION")

print("1. Visit cybercrime.gov.in.")
print("2. Select File a Complaint.")
print("3. Register using mobile number and OTP.")
print("4. Enter incident and transaction details.")
print("5. Upload supporting evidence.")
print("6. Submit and save acknowledgement number.")

print("\nRESULT: Incident details are prepared for cybercrime reporting.")
