# Design the procedure for enabling 2FA, installing security patches, and managing mobile application permissions.

print("MOBILE AND COMPUTER SECURITY")

print("\n1. ENABLE TWO-FACTOR AUTHENTICATION")

steps = [
    "Open the account settings and select Security.",
    "Choose Two-Factor Authentication (2FA).",
    "Select an authenticator application or OTP method.",
    "Scan the QR code if using an authenticator application.",
    "Enter the generated verification code.",
    "Save backup recovery codes in a secure location.",
    "Test the login process to confirm 2FA is working."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n2. SECURITY PATCH UPDATE PLAN")

updates = [
    "Open Windows Update or mobile Software Update settings.",
    "Check the currently installed operating system version.",
    "Search for available security patches and updates.",
    "Download updates only from official sources.",
    "Install important security and vulnerability fixes.",
    "Restart the device if required to complete installation.",
    "Check update history to verify successful installation.",
    "Enable automatic updates for future protection."
]

for i, step in enumerate(updates, 1):
    print(i, ".", step)

print("\n3. APPLICATION PERMISSION POLICY")

permissions = {
    "Camera": "Allow only when the application requires photography.",
    "Microphone": "Allow only for calling or recording applications.",
    "Contacts": "Deny if contact information is not required.",
    "Location": "Allow only while using navigation applications.",
    "SMS": "Restrict access to prevent OTP theft.",
    "Storage": "Allow only access required for application functions."
}

for permission, reason in permissions.items():
    print(permission, ":", reason)

print("\n4. PERMISSION MANAGEMENT PROCEDURE")

print("1. Open mobile Settings.")
print("2. Select Apps or Permission Manager.")
print("3. Choose the installed application.")
print("4. Review its requested permissions.")
print("5. Deny unnecessary sensitive permissions.")
print("6. Recheck permissions regularly.")

print("\nRESULT: 2FA, patch management and permission controls improve security.")
