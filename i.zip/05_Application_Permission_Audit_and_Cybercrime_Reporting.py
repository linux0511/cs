# Design application permission settings and explain the procedures for reporting cybercrime through the online portal and at a Cyber Crime Police Station.

print("APPLICATION PERMISSION AUDIT")

print("\n1. REVIEW OF SENSITIVE PERMISSIONS")

permissions = {
    "Camera": "Deny unless the application requires taking photographs.",
    "Microphone": "Deny unless voice recording or calling is required.",
    "Contacts": "Deny to prevent unnecessary contact data collection.",
    "Location": "Allow only while using the application if required.",
    "SMS": "Deny to protect OTP and message information."
}

for permission, reason in permissions.items():
    print(permission, ":", reason)

print("\n2. PERMISSION MANAGEMENT PROCEDURE")

steps = [
    "Open Settings on the mobile phone.",
    "Select Apps or Permission Manager.",
    "Choose the application to be reviewed.",
    "Open its permission settings.",
    "Identify unnecessary sensitive permissions.",
    "Select Deny or Allow only while using.",
    "Review permissions periodically."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n3. ONLINE CYBERCRIME COMPLAINT")

complaint = [
    "Visit the official portal cybercrime.gov.in.",
    "Select File a Complaint.",
    "Choose the appropriate cybercrime category.",
    "Register using the mobile number and OTP.",
    "Enter victim and incident information.",
    "Upload screenshots and transaction evidence.",
    "Submit the complaint and save acknowledgement number."
]

for i, step in enumerate(complaint, 1):
    print(i, ".", step)

print("\n4. CYBER CRIME POLICE STATION PROCEDURE")

police = [
    "Visit the nearest Cyber Crime Police Station.",
    "Carry identity proof and relevant evidence.",
    "Prepare a written complaint describing the incident.",
    "Submit transaction details and supporting documents.",
    "Request registration of the complaint or FIR, as applicable.",
    "Collect the acknowledgement for future reference."
]

for i, step in enumerate(police, 1):
    print(i, ".", step)

print("\nRESULT: Unnecessary application access is restricted and reporting procedures are prepared.")
