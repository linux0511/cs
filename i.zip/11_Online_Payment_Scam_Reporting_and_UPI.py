# Write the steps to report an online payment scam through the cybercrime portal and police station, and design UPI application security settings.

print("ONLINE PAYMENT SCAM REPORT")

print("\n1. CYBERCRIME PORTAL PROCEDURE")

steps = [
    "Call 1930 immediately to report financial fraud.",
    "Inform the bank and request transaction blocking if possible.",
    "Visit cybercrime.gov.in and select File a Complaint.",
    "Register using mobile number and OTP.",
    "Enter victim details, transaction ID, amount and incident time.",
    "Upload bank statement, screenshots and payment messages.",
    "Submit the complaint and save acknowledgement number."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n2. CYBER CRIME POLICE STATION")

print("1. Visit the nearest Cyber Crime Police Station.")
print("2. Carry identity proof and transaction evidence.")
print("3. Submit a written complaint.")
print("4. Provide bank statement and suspect details.")
print("5. Obtain complaint acknowledgement or FIR details.")

print("\n3. UPI SECURITY SETTINGS")

settings = [
    "Enable application lock using PIN or biometrics.",
    "Set a strong UPI PIN and never share it.",
    "Verify receiver name before sending money.",
    "Avoid unknown payment requests and QR codes.",
    "Enable transaction notifications.",
    "Set daily transaction limits.",
    "Use only official UPI applications."
]

for item in settings:
    print("-", item)

print("\nRESULT: Scam reporting and UPI protection procedures prepared.")
