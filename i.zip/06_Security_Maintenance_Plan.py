# Design two-factor authentication, security patch management, and a security checklist for UPI, mobile wallets, and net banking.

print("SECURITY MAINTENANCE PLAN")

print("\n1. TWO-FACTOR AUTHENTICATION")

steps = [
    "Open account settings and select Security.",
    "Choose Two-Factor Authentication.",
    "Select OTP or authenticator application.",
    "Verify identity using the received code.",
    "Save backup codes for account recovery.",
    "Test login to confirm 2FA is enabled."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n2. PATCH MANAGEMENT")

patches = [
    "Check operating system updates regularly.",
    "Enable automatic security updates.",
    "Download patches from official sources.",
    "Install critical security fixes first.",
    "Update antivirus and installed applications.",
    "Restart the device after installation.",
    "Verify update history and installed versions."
]

for item in patches:
    print("-", item)

print("\n3. ONLINE BANKING SECURITY CHECKLIST")

security = {
    "UPI": [
        "Use a strong UPI PIN.",
        "Verify receiver details before payment.",
        "Never share OTP or UPI PIN.",
        "Enable transaction notifications."
    ],
    "Mobile Wallet": [
        "Enable biometric or PIN lock.",
        "Use OTP verification where supported.",
        "Review transaction history.",
        "Remove unused linked cards."
    ],
    "Net Banking": [
        "Use strong unique passwords.",
        "Enable two-factor authentication.",
        "Use official banking websites.",
        "Avoid public Wi-Fi for transactions.",
        "Logout after completing transactions."
    ]
}

for name, items in security.items():
    print("\n", name)
    for item in items:
        print("-", item)

print("\nRESULT: Banking and device security controls are configured.")
