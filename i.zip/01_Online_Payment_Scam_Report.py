# Design the procedure for reporting an online payment scam, securing UPI and mobile wallets, and following safe net banking practices.

print("ONLINE PAYMENT SCAM REPORT")

print("\n1. REPORT THROUGH ONLINE CYBERCRIME PORTAL")

steps = [
    "Immediately call 1930 to report financial cyber fraud.",
    "Contact the bank and request blocking of the affected account or transaction.",
    "Visit https://cybercrime.gov.in and select File a Complaint.",
    "Register using your mobile number and verify through OTP.",
    "Enter victim details, fraud amount, transaction ID, date and time.",
    "Provide suspect details such as phone number, UPI ID or website.",
    "Upload screenshots, bank statements and payment messages.",
    "Submit the complaint and save the acknowledgement number."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\n2. REPORT AT CYBER CRIME POLICE STATION")

police = [
    "Visit the nearest Cyber Crime Police Station.",
    "Carry identity proof, bank statement and transaction details.",
    "Prepare a written complaint explaining how the fraud occurred.",
    "Submit screenshots, phone numbers, UPI IDs and other evidence.",
    "Request registration of the complaint or FIR, as applicable.",
    "Collect the acknowledgement and follow up with the investigating officer."
]

for i, step in enumerate(police, 1):
    print(i, ".", step)

print("\n3. UPI AND MOBILE WALLET SECURITY")

upi = [
    "Set a strong UPI PIN to prevent unauthorised transactions.",
    "Enable biometric or application lock to protect wallet access.",
    "Verify receiver name and UPI ID before sending money.",
    "Never share UPI PIN, OTP or screen-sharing access.",
    "Enable SMS and application transaction alerts.",
    "Set daily transaction limits to reduce financial loss.",
    "Install UPI applications only from official app stores."
]

for item in upi:
    print("-", item)

print("\n4. SAFE NET BANKING CHECKLIST")

bank = [
    "Use the official bank website with HTTPS connection.",
    "Create a strong and unique banking password.",
    "Enable two-factor authentication for additional protection.",
    "Avoid banking transactions on public Wi-Fi networks.",
    "Never share passwords, OTP, CVV or card details.",
    "Check account statements regularly for suspicious activity.",
    "Logout after completing transactions."
]

for item in bank:
    print("-", item)

print("\nRESULT: Security measures and complaint procedures reviewed.")
