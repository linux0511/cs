# Design an incident-reporting procedure for bank account compromise, list cybercrime complaint details, and explain public Wi-Fi risks and security settings.

print("BANK ACCOUNT COMPROMISE REPORT")

print("\n1. IMMEDIATE INCIDENT RESPONSE")

actions = [
    "Contact the bank immediately and report suspicious transactions.",
    "Request blocking of compromised cards, UPI or internet banking access.",
    "Change banking passwords and reset UPI PIN.",
    "Call 1930 immediately if financial fraud has occurred.",
    "Register a complaint through cybercrime.gov.in.",
    "Monitor account statements for further unauthorised transactions."
]

for i, action in enumerate(actions, 1):
    print(i, ".", action)

print("\n2. INFORMATION REQUIRED FOR CYBERCRIME COMPLAINT")

details = [
    "Victim name, address and registered mobile number.",
    "Bank name and relevant account details.",
    "Transaction ID and payment reference number.",
    "Fraud amount and transaction date and time.",
    "Suspect mobile number, email ID or UPI ID.",
    "Screenshots of messages, emails and payment notifications.",
    "Bank statement showing the suspicious transaction."
]

for item in details:
    print("-", item)

print("\n3. PUBLIC WI-FI SECURITY RISKS")

risks = {
    "Man-in-the-Middle Attack": "Attacker intercepts communication between users and websites.",
    "Fake Hotspot": "Fraudulent Wi-Fi network tricks users into connecting.",
    "Packet Sniffing": "Attackers capture unprotected network traffic.",
    "Password Theft": "Login credentials may be exposed on insecure networks.",
    "Malware Attack": "Unsafe network connections may expose devices to malicious content."
}

for risk, explanation in risks.items():
    print(risk, ":", explanation)

print("\n4. WI-FI SECURITY SETTINGS")

settings = [
    "Disable automatic connection to unknown Wi-Fi networks.",
    "Avoid online banking and sensitive transactions on public Wi-Fi.",
    "Use a trusted VPN when appropriate.",
    "Enable firewall protection on computers.",
    "Disable file and printer sharing on public networks.",
    "Use HTTPS websites and keep devices updated.",
    "Forget unknown networks after use."
]

for item in settings:
    print("-", item)

print("\nRESULT: Incident response and Wi-Fi protection procedures prepared.")
