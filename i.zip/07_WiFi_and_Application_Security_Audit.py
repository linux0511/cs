# Design Wi-Fi security settings, identify possible threats, and review excessive mobile application permissions.

print("WI-FI AND APPLICATION SECURITY AUDIT")

print("\n1. POSSIBLE WI-FI THREATS")

threats = {
    "Fake Hotspot": "Attacker creates a fake network to collect user information.",
    "Packet Sniffing": "Unprotected network traffic may be captured.",
    "MITM Attack": "Attacker intercepts communication between two parties.",
    "Password Theft": "Login credentials may be exposed.",
    "Malware": "Malicious content may infect connected devices."
}

for name, explanation in threats.items():
    print(name, ":", explanation)

print("\n2. COMPUTER WI-FI SECURITY SETTINGS")

computer = [
    "Enable firewall protection.",
    "Disable automatic connection to unknown networks.",
    "Turn off file and printer sharing on public networks.",
    "Keep antivirus and operating system updated.",
    "Avoid sensitive transactions on public Wi-Fi."
]

for item in computer:
    print("-", item)

print("\n3. MOBILE WI-FI SECURITY SETTINGS")

mobile = [
    "Disable automatic Wi-Fi connection.",
    "Avoid unknown and unsecured hotspots.",
    "Use trusted VPN protection when appropriate.",
    "Forget public networks after use.",
    "Keep mobile software updated."
]

for item in mobile:
    print("-", item)

print("\n4. INSTALLED APPLICATION PERMISSION REPORT")

apps = {
    "Calculator": ["Contacts", "Location", "Microphone"],
    "Game Application": ["Camera", "Contacts", "Location"],
    "Messaging Application": ["Camera", "Microphone", "Contacts"]
}

for app, permissions in apps.items():
    print("\nApplication:", app)
    for permission in permissions:
        print("-", permission, ": Review necessity before allowing.")

print("\n5. RECOMMENDED PERMISSION SETTINGS")

settings = {
    "Camera": "Allow only when required.",
    "Microphone": "Deny unnecessary access.",
    "Contacts": "Allow only for trusted communication apps.",
    "Location": "Allow only while using the application."
}

for permission, setting in settings.items():
    print(permission, ":", setting)

print("\nRESULT: Wi-Fi risks and excessive application permissions are reviewed.")
