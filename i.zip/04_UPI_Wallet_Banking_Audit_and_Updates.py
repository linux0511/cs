# Design a security audit for UPI and mobile wallets, recommend secure net banking practices, and explain computer and mobile security update procedures.

print("SECURITY AUDIT REPORT")

print("\n1. UPI APPLICATION AUDIT")

upi = [
    "Check whether UPI PIN protection is enabled.",
    "Verify that biometric or application lock is configured.",
    "Check whether transaction alerts are enabled.",
    "Verify receiver name and UPI ID before payment.",
    "Review transaction history for suspicious payments."
]

for item in upi:
    print("-", item)

print("\n2. MOBILE WALLET AUDIT")

wallet = [
    "Enable PIN or biometric authentication.",
    "Enable OTP verification wherever supported.",
    "Remove unused linked bank accounts and cards.",
    "Check wallet balance and transaction history regularly.",
    "Install application updates from official stores."
]

for item in wallet:
    print("-", item)

print("\n3. NET BANKING SECURITY RECOMMENDATIONS")

bank = [
    "Use the official banking website with HTTPS.",
    "Create a strong and unique password.",
    "Enable two-factor authentication.",
    "Avoid logging in through public computers.",
    "Never share OTP, CVV or banking passwords.",
    "Check statements and enable transaction alerts.",
    "Logout after completing banking activities."
]

for item in bank:
    print("-", item)

print("\n4. COMPUTER SECURITY UPDATE PROCEDURE")

computer = [
    "Open Windows Settings.",
    "Select Windows Update.",
    "Click Check for Updates.",
    "Download available security patches.",
    "Install updates and restart the computer.",
    "Check update history to confirm installation."
]

for i, step in enumerate(computer, 1):
    print(i, ".", step)

print("\n5. MOBILE SECURITY UPDATE PROCEDURE")

mobile = [
    "Open mobile Settings.",
    "Select Software Update.",
    "Check for available updates.",
    "Download the update using a trusted connection.",
    "Install and restart the mobile device.",
    "Verify the installed software version."
]

for i, step in enumerate(mobile, 1):
    print(i, ".", step)

print("\nRESULT: Security audit and update procedures completed.")
