# Design security practices for UPI, mobile wallets, and net banking, and explain software update status checks and patch maintenance procedures.

print("ONLINE BANKING SECURITY REPORT")

print("\n1. UPI SECURITY PRACTICES")

upi = [
    "Create a strong UPI PIN and never share it.",
    "Verify the receiver name before making payments.",
    "Remember that entering a UPI PIN authorises payment, not receipt.",
    "Avoid scanning unknown QR codes.",
    "Enable transaction alerts and set payment limits."
]

for item in upi:
    print("-", item)

print("\n2. MOBILE WALLET SECURITY")

wallet = [
    "Enable application lock using PIN or biometrics.",
    "Use OTP verification wherever available.",
    "Avoid storing unnecessary card information.",
    "Check transaction history regularly.",
    "Report unauthorised transactions immediately."
]

for item in wallet:
    print("-", item)

print("\n3. NET BANKING SECURITY")

bank = [
    "Access banking only through the official website.",
    "Use a strong password that is not reused elsewhere.",
    "Enable two-factor authentication.",
    "Avoid banking on public or shared computers.",
    "Never share OTP, CVV or password.",
    "Logout after every banking session."
]

for item in bank:
    print("-", item)

print("\n4. COMPUTER AND MOBILE UPDATE STATUS")

updates = {
    "Operating System": "Check and install latest security patches.",
    "Mobile Software": "Verify the latest available version.",
    "Applications": "Update through official app stores.",
    "Antivirus": "Update virus definitions regularly."
}

for item, status in updates.items():
    print(item, ":", status)

print("\n5. PATCH MAINTENANCE PROCEDURE")

steps = [
    "Check available software updates.",
    "Download updates from official sources.",
    "Install pending security patches.",
    "Restart the device if required.",
    "Verify installation through update history.",
    "Enable automatic updates."
]

for i, step in enumerate(steps, 1):
    print(i, ".", step)

print("\nRESULT: Banking security and patch maintenance plan prepared.")
